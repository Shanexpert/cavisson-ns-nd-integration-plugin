/*-----------------------------------------------------------------------------
    Name: exit_script
    Recorded By: netstorm
    Date of recording: 03/15/2017 11:00:23
    Flow details:
    Build details: 4.1.7 (build# 34)
    Modification History:
-----------------------------------------------------------------------------*/

package com.cavisson.scripts.__Java_Scr;
import pacJnvmApi.NSApi;

public class exit_script
{
    public static int execute(NSApi nsApi)
    {
        return 0;
    }
}
