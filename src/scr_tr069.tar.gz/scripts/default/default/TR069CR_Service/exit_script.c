#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void exit_script() {
  // printf("%s: Called\n", (char*)__FUNCTION__);
}
