#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int exit_script()
{
//fprintf(stderr, "$$$$$$$$$$$$$$$$$exit_script()\n");
return 0;
}
